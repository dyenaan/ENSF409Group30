package edu.ucalgary.ensf409;

public class HamperAlreadyFoundException extends Exception{
    public HamperAlreadyFoundException(String e) {
        super(e);
    }
}