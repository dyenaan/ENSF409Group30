package edu.ucalgary.ensf409;

import java.util.*;

public class Family{
	private final Person[] PEOPLE;
	private final ArrayList<Map<String, String>> HAMPER;
	private final int MALECOUNT;
	private final int FEMALECOUNT;
	private final int CHILDUECOUNT;
	private final int CHILDOECOUNT;

    //private GUIOrderID order = new GUIOrderID();

	public Family(int maleCount, int femaleCount, int childUECount, int childOECount) throws HamperAlreadyFoundException, StockNotAvailableException {

        this.MALECOUNT = maleCount;
        this.FEMALECOUNT = femaleCount;
        this.CHILDUECOUNT = childOECount;
        this.CHILDOECOUNT = childUECount;

        int j = 0;
        PEOPLE = new Person[maleCount + femaleCount + childUECount + childOECount];
		for (int i = 0; i < MALECOUNT; i++) {
            PEOPLE[j] = new Person(1);
            j++;
        }
        for (int i = 0; i < FEMALECOUNT; i++) {
            PEOPLE[j] = new Person(2);
            j++;
        }
        for (int i = 0; i < CHILDUECOUNT; i++) {
            PEOPLE[j] = new Person(3);
            j++;
        }
        for (int i = 0; i < CHILDOECOUNT; i++) {
            PEOPLE[j] = new Person(4);
            j++;
        }

        Algorithm a = new Algorithm(PEOPLE);
        this.HAMPER = a.getBestHamper();
	}

	public Person[] getPeople(){
		return this.PEOPLE;
	}

	public ArrayList<Map<String, String>> getHamper(){
		return this.HAMPER;
	}

    public int getClientCount(String clientType) {
        switch (clientType) {
            case "Male":
                return this.MALECOUNT;
            case "Female":
                return this.FEMALECOUNT;
            case "ChildOE":
                return this.CHILDOECOUNT;
            case "ChildUE":
                return this.CHILDUECOUNT;
            default:
                throw new IllegalArgumentException("Did not recognize input");
        }
    }
}