package edu.ucalgary.ensf409;

import java.util.Map;

public class Person {
    private final int CLIENTID;
    private final int CALORIES;
    private final int WHOLEGRAINS;
    private final int FRUITVEGGIES;
    private final int PROTEIN;
    private final int OTHER;

    Person(int clientID) {
        Database db = new Database("jdbc:mysql://localhost/food_inventory", "student", "ensf");
        db.initializeConnection();
        Map<String, String> clientNeeds = db.selectClientNeeds(String.valueOf(clientID));
        db.close();

        this.CLIENTID = clientID;
        this.CALORIES = Integer.parseInt(clientNeeds.get("Calories"));
        this.WHOLEGRAINS = Integer.parseInt(clientNeeds.get("WholeGrains"));
        this.FRUITVEGGIES = Integer.parseInt(clientNeeds.get("FruitVeggies"));
        this.PROTEIN = Integer.parseInt(clientNeeds.get("Protein"));
        this.OTHER = Integer.parseInt(clientNeeds.get("Other"));
    }

    // @TODO Use enumeration to implement the getter properly!
    public double getNutrition(String nutrition) {
        switch (nutrition) {
            case "Calories":
                return CALORIES;
            case "WholeGrains":
                return WHOLEGRAINS;
            case "FruitVeggies":
                return FRUITVEGGIES;
            case "Protein":
                return PROTEIN;
            case "Other":
                return OTHER;
            default:
                throw new IllegalArgumentException("Did not recognize input");
        }
    }
    public int getClientID() {
        return this.CLIENTID;
    }
}
