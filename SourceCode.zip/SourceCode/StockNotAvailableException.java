package edu.ucalgary.ensf409;

public class StockNotAvailableException extends Exception{
    public StockNotAvailableException(String e) {
        super(e);
    }
}
